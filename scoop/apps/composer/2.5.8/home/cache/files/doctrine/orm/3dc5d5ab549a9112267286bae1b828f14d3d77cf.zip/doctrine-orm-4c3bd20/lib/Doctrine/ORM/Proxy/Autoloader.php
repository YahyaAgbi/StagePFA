<?php

declare(strict_types=1);

namespace Doctrine\ORM\Proxy;

use Doctrine\Common\Proxy\Autoloader as BaseAutoloader;

/** @deprecated use \Doctrine\Common\Proxy\Autoloader instead */
class Autoloader extends BaseAutoloader
{
}
