<?php

declare(strict_types=1);

namespace Doctrine\ORM\Mapping;

/** @deprecated Use {@see MappingAttribute} instead. */
interface Annotation
{
}
