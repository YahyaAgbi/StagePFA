<?php

namespace Facebook\WebDriver\Exception;

/**
 * Common interface to identify all exceptions thrown in php-webdriver (both those of WebDriver protocol and internal).
 */
interface PhpWebDriverExceptionInterface
{
}
