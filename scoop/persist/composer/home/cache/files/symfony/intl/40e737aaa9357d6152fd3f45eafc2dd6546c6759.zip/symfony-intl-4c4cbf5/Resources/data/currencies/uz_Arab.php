<?php

return [
    'Names' => [
        'AFN' => [
            0 => '؋',
            1 => 'افغانی',
        ],
    ],
];
