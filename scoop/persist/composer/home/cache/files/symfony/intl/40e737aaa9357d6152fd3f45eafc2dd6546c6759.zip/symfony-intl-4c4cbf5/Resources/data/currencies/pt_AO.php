<?php

return [
    'Names' => [
        'AOA' => [
            0 => 'Kz',
            1 => 'kwanza angolano',
        ],
    ],
];
