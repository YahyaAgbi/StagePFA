<?php

return [
    'Names' => [
        'RWF' => [
            0 => 'RF',
            1 => 'franc rwandais',
        ],
    ],
];
