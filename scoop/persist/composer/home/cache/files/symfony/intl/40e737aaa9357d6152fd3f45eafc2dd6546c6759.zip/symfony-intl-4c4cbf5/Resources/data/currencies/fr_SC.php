<?php

return [
    'Names' => [
        'SCR' => [
            0 => 'SR',
            1 => 'roupie des Seychelles',
        ],
    ],
];
