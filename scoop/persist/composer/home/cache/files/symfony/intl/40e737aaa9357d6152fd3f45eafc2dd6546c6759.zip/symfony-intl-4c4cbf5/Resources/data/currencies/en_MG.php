<?php

return [
    'Names' => [
        'MGA' => [
            0 => 'Ar',
            1 => 'Malagasy Ariary',
        ],
    ],
];
