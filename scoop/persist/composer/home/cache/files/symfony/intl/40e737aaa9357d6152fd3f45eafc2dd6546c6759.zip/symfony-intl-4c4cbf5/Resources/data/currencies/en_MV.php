<?php

return [
    'Names' => [
        'MVR' => [
            0 => 'Rf',
            1 => 'Maldivian Rufiyaa',
        ],
    ],
];
