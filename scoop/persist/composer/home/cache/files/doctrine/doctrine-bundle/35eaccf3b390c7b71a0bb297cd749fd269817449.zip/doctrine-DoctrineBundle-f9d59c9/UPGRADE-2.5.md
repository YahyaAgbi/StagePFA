UPGRADE FROM 2.4 to 2.5
=======================

Configuration
--------
 * The `metadata_cache_driver` configuration key is no longer deprecated.

